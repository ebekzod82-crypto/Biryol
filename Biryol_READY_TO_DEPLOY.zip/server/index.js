
const express=require("express"), path=require("path"), Database=require("better-sqlite3"),
bcrypt=require("bcryptjs"), jwt=require("jsonwebtoken");
const app=express(), db=new Database("biryol.db"), SECRET=process.env.JWT_SECRET||"change-this-secret";
app.use(express.json()); app.use(express.static(path.join(__dirname,"../public")));
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT UNIQUE,password TEXT,role TEXT DEFAULT 'customer');
CREATE TABLE IF NOT EXISTS businesses(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,name TEXT,category TEXT,description TEXT,address TEXT,lat REAL,lng REAL,rating REAL DEFAULT 0,plan TEXT DEFAULT 'free');
CREATE TABLE IF NOT EXISTS listings(id INTEGER PRIMARY KEY AUTOINCREMENT,business_id INTEGER,type TEXT,name TEXT,description TEXT,price REAL,image TEXT);
CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER,business_id INTEGER,UNIQUE(user_id,business_id));
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,business_id INTEGER,rating INTEGER,text TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,business_id INTEGER,status TEXT DEFAULT 'new',total REAL DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
function auth(req,res,next){try{const h=req.headers.authorization||""; req.user=jwt.verify(h.replace("Bearer ",""),SECRET);next()}catch(e){res.status(401).json({error:"Kirish talab qilinadi"})}}
app.post("/api/register",(req,res)=>{const {name,phone,password,role="customer"}=req.body;if(!name||!phone||!password)return res.status(400).json({error:"Maydonlarni to‘ldiring"});try{const hash=bcrypt.hashSync(password,10),x=db.prepare("INSERT INTO users(name,phone,password,role) VALUES(?,?,?,?)").run(name,phone,hash,role);const token=jwt.sign({id:x.lastInsertRowid,name,role},SECRET,{expiresIn:"30d"});res.json({token,user:{id:x.lastInsertRowid,name,phone,role}})}catch(e){res.status(400).json({error:"Bu telefon allaqachon ro‘yxatdan o‘tgan"})}});
app.post("/api/login",(req,res)=>{const u=db.prepare("SELECT * FROM users WHERE phone=?").get(req.body.phone);if(!u||!bcrypt.compareSync(req.body.password,u.password))return res.status(401).json({error:"Telefon yoki parol noto‘g‘ri"});res.json({token:jwt.sign({id:u.id,name:u.name,role:u.role},SECRET,{expiresIn:"30d"}),user:{id:u.id,name:u.name,phone:u.phone,role:u.role}})});
app.get("/api/me",auth,(req,res)=>res.json(req.user));
app.get("/api/businesses",(req,res)=>{let q=req.query.q||"",cat=req.query.category||"";let sql="SELECT * FROM businesses WHERE name LIKE ? AND category LIKE ? ORDER BY rating DESC";res.json(db.prepare(sql).all("%"+q+"%","%"+cat+"%"))});
app.post("/api/businesses",auth,(req,res)=>{if(!["business","admin"].includes(req.user.role))return res.status(403).json({error:"Biznes akkaunti kerak"});let b=req.body,x=db.prepare("INSERT INTO businesses(user_id,name,category,description,address,lat,lng) VALUES(?,?,?,?,?,?,?)").run(req.user.id,b.name,b.category,b.description||"",b.address||"",b.lat||41.3111,b.lng||69.2797);res.json({id:x.lastInsertRowid})});
app.get("/api/listings",(req,res)=>res.json(db.prepare("SELECT l.*,b.name business_name FROM listings l JOIN businesses b ON b.id=l.business_id WHERE l.name LIKE ? ORDER BY l.id DESC").all("%"+(req.query.q||"")+"%")));
app.post("/api/listings",auth,(req,res)=>{let b=db.prepare("SELECT * FROM businesses WHERE user_id=?").get(req.user.id);if(!b)return res.status(400).json({error:"Avval biznes yarating"});let x=req.body,r=db.prepare("INSERT INTO listings(business_id,type,name,description,price,image) VALUES(?,?,?,?,?,?)").run(b.id,x.type||"product",x.name,x.description||"",x.price||0,x.image||"");res.json({id:r.lastInsertRowid})});
app.post("/api/favorites/:id",auth,(req,res)=>{db.prepare("INSERT OR IGNORE INTO favorites VALUES(?,?)").run(req.user.id,req.params.id);res.json({ok:true})});
app.get("/api/favorites",auth,(req,res)=>res.json(db.prepare("SELECT b.* FROM favorites f JOIN businesses b ON b.id=f.business_id WHERE f.user_id=?").all(req.user.id)));
app.post("/api/reviews",auth,(req,res)=>{let {business_id,rating,text}=req.body;db.prepare("INSERT INTO reviews(user_id,business_id,rating,text) VALUES(?,?,?,?)").run(req.user.id,business_id,rating,text||"");db.prepare("UPDATE businesses SET rating=(SELECT ROUND(AVG(rating),1) FROM reviews WHERE business_id=?) WHERE id=?").run(business_id,business_id);res.json({ok:true})});
app.get("/api/reviews/:id",(req,res)=>res.json(db.prepare("SELECT r.*,u.name FROM reviews r JOIN users u ON u.id=r.user_id WHERE business_id=? ORDER BY r.id DESC").all(req.params.id)));
app.post("/api/orders",auth,(req,res)=>{let x=req.body,r=db.prepare("INSERT INTO orders(user_id,business_id,total) VALUES(?,?,?)").run(req.user.id,x.business_id,x.total||0);res.json({id:r.lastInsertRowid,status:"new"})});
app.get("/api/orders",auth,(req,res)=>res.json(db.prepare("SELECT o.*,b.name business_name FROM orders o JOIN businesses b ON b.id=o.business_id WHERE o.user_id=? ORDER BY o.id DESC").all(req.user.id)));
app.get("/api/admin/stats",auth,(req,res)=>{if(req.user.role!=="admin")return res.status(403).json({error:"Admin only"});res.json({users:db.prepare("SELECT COUNT(*) n FROM users").get().n,businesses:db.prepare("SELECT COUNT(*) n FROM businesses").get().n,listings:db.prepare("SELECT COUNT(*) n FROM listings").get().n,orders:db.prepare("SELECT COUNT(*) n FROM orders").get().n})});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../public/index.html")));
app.listen(process.env.PORT||3000,()=>console.log("Biryol running on http://localhost:3000"));
