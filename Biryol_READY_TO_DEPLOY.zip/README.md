# Biryol — deploy-ready MVP

## Ishga tushirish
1. Node.js 20+ o‘rnating.
2. Terminalda loyiha papkasiga kiring.
3. `npm install`
4. `npm start`
5. Brauzerda `http://localhost:3000` ni oching.

## Rollar
- customer — mijoz
- business — tadbirkor
- admin — administrator

Admin uchun ro‘yxatdan o‘tishda `admin` roli ochiq qoldirilmagan; ishlab chiqarish serverida admin foydalanuvchisini alohida yaratish kerak.

## Muhim
Bu MVP haqiqiy server/API va SQLite ma'lumotlar bazasiga ega. Ishlab chiqarishga chiqarishdan oldin JWT_SECRET, HTTPS, SMS login, real xarita API, fayl saqlash, payment gateway, email/SMS bildirishnomalar va production DB (PostgreSQL kabi) sozlanishi kerak.
